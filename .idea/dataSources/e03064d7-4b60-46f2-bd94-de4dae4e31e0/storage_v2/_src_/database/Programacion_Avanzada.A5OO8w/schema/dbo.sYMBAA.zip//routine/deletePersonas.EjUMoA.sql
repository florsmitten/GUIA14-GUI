
create procedure deletePersonas
  @dni int
 as
  DELETE FROM Personas WHERE dni=@dni;
go

