
CREATE PROCEDURE calcularMililitros

  @suma float output
  as 
  DECLARE @fecha date
	SET @fecha = GETDATE()

  select @suma=sum(e.cantExtraida)
        from extracciones as e
        join donadores as d
        on e.dniDonador=d.dni
        where d.donaSangre = 1 AND d.donaPlaquetas = 1 AND d.donaPlasma = 1 AND DATEDIFF( month , e.fechaDonacion , @fecha) < 6;
go

