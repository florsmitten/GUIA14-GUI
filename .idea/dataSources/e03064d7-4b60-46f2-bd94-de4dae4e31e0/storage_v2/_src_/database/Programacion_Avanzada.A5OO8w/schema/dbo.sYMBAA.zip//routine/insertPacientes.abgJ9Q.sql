
create procedure insertPacientes
  @dni int,
  @enfermedad varchar (100),
  @inicioTratamiento date
 as
  Insert into Pacientes values (@dni, @enfermedad, @inicioTratamiento);
go

