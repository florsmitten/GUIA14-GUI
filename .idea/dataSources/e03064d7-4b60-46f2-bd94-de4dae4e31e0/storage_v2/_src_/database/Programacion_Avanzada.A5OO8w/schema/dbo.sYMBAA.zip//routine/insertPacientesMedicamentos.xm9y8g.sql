
create procedure insertPacientesMedicamentos
  @dni int,
  @idMed int
 as
  Insert into PacientesMedicamentos values (@dni, @idMed);
go

