
create procedure deleteExtracciones
  @dni int
 as
  DELETE FROM Extracciones WHERE dniDonador=@dni;
go

