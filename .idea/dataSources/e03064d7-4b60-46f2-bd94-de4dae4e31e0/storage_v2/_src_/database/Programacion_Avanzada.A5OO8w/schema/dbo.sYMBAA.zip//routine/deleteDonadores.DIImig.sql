
create procedure deleteDonadores
  @dni int
 as
  DELETE FROM Donadores WHERE dni=@dni;
go

