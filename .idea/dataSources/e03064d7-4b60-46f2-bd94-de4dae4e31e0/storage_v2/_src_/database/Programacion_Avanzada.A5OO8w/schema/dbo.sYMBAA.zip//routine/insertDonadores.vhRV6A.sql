
create procedure insertDonadores
  @dni int,
  @donaSangre bit,
  @donaPlasma bit,
  @donaPlaquetas bit
 as
  Insert into Donadores values (@dni,@donaSangre,@donaPlasma,@donaPlaquetas);
go

