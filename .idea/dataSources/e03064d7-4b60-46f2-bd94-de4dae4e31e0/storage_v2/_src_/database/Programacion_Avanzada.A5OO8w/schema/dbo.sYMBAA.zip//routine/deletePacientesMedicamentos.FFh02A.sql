
create procedure deletePacientesMedicamentos
  @dni int
 as
  DELETE FROM PacientesMedicamentos WHERE dni=@dni;
go

