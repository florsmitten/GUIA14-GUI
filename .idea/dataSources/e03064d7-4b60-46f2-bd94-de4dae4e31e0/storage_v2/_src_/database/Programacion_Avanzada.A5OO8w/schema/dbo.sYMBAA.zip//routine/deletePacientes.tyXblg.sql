
create procedure deletePacientes
  @dni int
 as
  DELETE FROM Pacientes WHERE dni=@dni;
go

