
create procedure insertPersonas
	@dni int,
	@nombre varchar(100),
	@apellido varchar(100),
	@sexo char,
	@fechaNac date,
	@provincia int,
	@localidad int,
	@tipoSangre int,
	@tipoPersona int
 as
  Insert into Personas values (@dni, @nombre, @apellido, @sexo, @fechaNac, @provincia, @localidad, @tipoSangre, @tipoPersona)
go

